MATCHER
=======================

MATCHER is intended to be run with the Anaconda distribution of Python (https://www.continuum.io/downloads). 

Installation: pip install <path-to-matcher>

Full HTML documentation is available in docs/build/html/index.html

MATCHER_demo.ipynb is a Jupyter notebook demonstrating how to run MATCHER on synthetic data provided with the package.