MATCHER
=======================

README file for MATCHER. 

Installation: 
> conda update scipy
> pip install matcher